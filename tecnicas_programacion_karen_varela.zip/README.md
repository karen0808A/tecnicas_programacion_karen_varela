# Técnicas de Programación - Ejemplos

Repositorio generado para Karen Varela.

Incluye ejemplos de:
- Abstracción
- Encapsulación
- Herencia
- Polimorfismo
